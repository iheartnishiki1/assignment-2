﻿using System;

public class Class1
{
	public Class1()
	{
        private decimal ordertoatal;
        public shop()
        {
        ordertoatal = 0;
        }
        public void RUN()
        {
            //All shop logic runs here 
            Displayintro();

            sellitem("iron sowrd", 10.5m);
            sellitem("diamond sowrd", 24.7m);

            displayoutro();
        }

        private void Displayintro()
        {
           Console.writeline("********************************")
           Console.writeline("*************Item shop*******************")



        }
        private void sellitem(string itemname, decimal cost)
        {
            Console.WriteLine($"buy?(n) {itemname} for {cost:C2}? (y/n) ");
            string response = Console.readline().ToUpper();
            if (response == "Y")
            {
                console.writeline ("how many would you like?");
                string numResponse = ReadLine();
                try
                {
                    int quantity = convert.toInt32(numResponse);
                    decimal itemtotal = cost * quantity;
                    ordertoatal += itemtotal;
                    console.writeline($"alright {quantity}x {itemname} is going to cost you... {itemtotal:C2}");
                }
                catch (formatexception)
                {
                    console.writeline("error please try again.");
                    sellitem(itemname, cost);
                    return;
                }
                catch (overflowexpection)
                {
                    console.writeline("error please try again.");
                    sellitem(itemname, cost);
                    return;
                }

            }
            else
            {
                console.writeline($"removed(n) {itemname} from your cart.");
            }
        }

        private void displayordetotal()

        {
        console.writline($ >"your total is: {itemtotal:C2}.\");
        }

        private void displayoutro()
        {
            Console.WriteLine("thanks for shopping");
            Console.WriteLine("press any key to exit");
            Console.ReadKey();
        }
    }
}
