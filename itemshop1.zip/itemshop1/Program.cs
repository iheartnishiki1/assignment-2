﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace itemshop1
{
    internal class program
    {
        static void main(string[] args)
        {
            shop myshop = new itemshop1();
            myshop.Run();
        }
    }
       

}
